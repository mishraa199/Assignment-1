#include <stdio.h>
int main ()
{
    printf("Hello\nStudent");
    return 0;
}
