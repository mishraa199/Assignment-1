#include <stdio.h>

int main ()
{
    printf("\"Hello, Madan Mohan Mishra\"");
    return 0;
}
