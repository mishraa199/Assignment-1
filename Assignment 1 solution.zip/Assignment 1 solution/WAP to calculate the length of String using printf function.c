#include <stdio.h>
int main ()
{
    int x;
     x=printf("ineuron");
     printf("Length of \"ineuron\" is %d",x);
     return 0;

}
