#include <stdio.h>

int main ()
{
    int day,month,year;
    printf("Enter Date in DD/MM/YYYY Format\n");
    scanf("%d/%d/%d", &day, &month, &year);
    printf("Day -%d, Month - %d, Year - %d",day,month,year);
    return 0;
}
