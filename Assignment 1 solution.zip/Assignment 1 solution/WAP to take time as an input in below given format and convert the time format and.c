#include <stdio.h>

int main ()
{
    int hour,min;
    printf("Enter the time in HH:MM Format\n");
    scanf("%d:%d",&hour,&min);
    printf("%d Hours and %d Minutes",hour,min);
    return 0;

}
