#include<stdio.h>
int main ()
{
    int a,b,c;
    printf("Enter a first number");
    scanf("%d",&a);
    printf("Enter b second number");
    scanf("%d",&b);
    c= a+b;
    prinf("sum of two numbers %d",c=a+b);
    return 0;
}
