#include <stdio.h>
int main ()
{
    printf("\"MySirG\"");
    return 0;

}
